from django.contrib import admin
from .models import myBlog
# Register your models here.

admin.site.register(myBlog)