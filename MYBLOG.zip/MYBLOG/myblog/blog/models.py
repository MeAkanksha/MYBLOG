from django.db import models
from autoslug import AutoSlugField
# Create your models here.

class myBlog(models.Model):
    blog_id = models.AutoField(primary_key=True)
    blog_title = models.CharField(max_length=200)
    blog_desc = models.TextField()
    blog_slug=AutoSlugField(populate_from='blog_title',unique=True,null=True,default=None)

    def __str__(self):
        return self.blog_title

