from django.http.response import HttpResponse
from django.shortcuts import render
from .models import myBlog
# Create your views here.


def home(request):
    data = myBlog.objects.all()
    return render(request,'index.html',{'blogs':data})

def blog(request,blog_slug):
    data = myBlog.objects.all().filter(blog_slug=blog_slug)
    print('-------------------------------------------------------------------------------------',data)
    return render(request,'blog.html',{'blogs':data})